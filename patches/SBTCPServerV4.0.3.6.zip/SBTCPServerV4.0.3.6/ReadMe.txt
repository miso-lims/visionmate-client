SBTCPServer.dll

Version: 4.0.3.6
Date: 26.03.2018


Updates:

1)	'Reset Scanner' command now resets scanner status to value 33.  (Not scanning, not data sent, not data ready).
2)	'Reset Scanner' command now clears results data.  Subsequent 'Get Data' command returns 'OKD' with no data.

Usage instructions:

1)	Close VisionMate software.
2)	Copy and replace the file 'SBTCPServer.dll' into the folder 'C:\ProgramData\Thermo\VisionMate Suite\Plugins".
3)	The VisionMate software may now be restarted and the updated functionality will be present.

Notes:

If successful, this version of SBTCPServer.dll will be included in future standard VisionMate Suite installers.

Test results for this version are included in the parent zip file in 'TCP_Reset_Command_Test_v4.0.3.6.xlsx'.