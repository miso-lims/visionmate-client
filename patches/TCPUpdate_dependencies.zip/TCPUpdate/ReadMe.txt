Required dependancies for SBTCPServer.dll with VisonMate 4.0.4.1

Installation:

1)	Close the VisionMate application.
2)	Please copy and replace both files (SBUtil.dll and SBServerContract.dll) into VisionMate application directory, typically: "C:\Program Files (x86)\Thermo Scientific\VisionMate Suite".